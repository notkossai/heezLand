import { useState } from "react";
import { NavLink } from "react-router-dom";
import game from "/src/assets/icons/game.png"
import book from "/src/assets/icons/book.png"
import hero from "/src/assets/hero.png"
import home from "/src/assets/home.png"
import LanguageSelect from "/src/Components/LanguageSelect"
import BurgerMenu from "/src/Components/BurgerMenu"
import X from "/src/Components/X"
import "./Nav.css"


export default function Nav({ language, setLanguage }) {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="nav-container">
            <div className="save-terry-logo">
                <span>Save Terry</span>
            </div>

            <div className={`nav-bar ${isOpen ? "active" : ""}`}>

                <NavLink to="/"  className={({ isActive }) => (isActive ? "nav-icon-link active" : "nav-icon")}>
                    <img src={home} id="earth-icon" className="nav-icon" alt="Earth Icon" />
                </NavLink>
                <NavLink to="/games"  className={({ isActive }) => (isActive ? "nav-icon-link active" : "nav-icon")}>
                    <img src={game} id="game-icon" className="nav-icon" alt="Games Icon" />
                </NavLink>
                <NavLink to="/books"  className={({ isActive }) => (isActive ? "nav-icon-link active" : "nav-icon")}>
                    <img src={book} id="book-icon" className="nav-icon" alt="Books Icon" />
                </NavLink>
                <NavLink to="/heros"  className={({ isActive }) => (isActive ? "nav-icon-link active" : "nav-icon")}>
                    <img src={hero} id="diy-icon" className="nav-icon" alt="DIY Icon" />
                </NavLink>

            </div>
            <BurgerMenu
                className={`burger-menu ${isOpen ? "active" : ""}`}
                onClick={() => setIsOpen(true)}
            />
            <X
                className={`burger-exit ${isOpen ? "active" : ""}`}
                onClick={() => setIsOpen(false)}
            />
            <LanguageSelect language={language} setLanguage={setLanguage} className="language" />

        </div>


    )
}
