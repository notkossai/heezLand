import { motion } from 'motion/react';
import './FloatingElement.css';

export function FloatingElement({
  children,
  delay = 0,
  duration = 10,
  startX = '10%',
  startY = '-10%',
}) {
  return (
    <motion.div
      className="floating-element"
      initial={{ 
        x: startX, 
        y: startY,
        rotate: 0 
      }}
      animate={{
        y: '110vh',
        x: [startX, `calc(${startX} + 50px)`, `calc(${startX} - 30px)`, startX],
        rotate: [0, 180, 360],
      }}
      transition={{
        duration: duration,
        repeat: Infinity,
        ease: 'linear',
        delay: delay,
      }}
    >
      {children}
    </motion.div>
  );
}
