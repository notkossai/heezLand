import { supabase } from "/src/supabaseClient";
import { useQuery } from "@tanstack/react-query";

import PostItem from "/src/Components/PostItem";

import "./PostList.css"


const fetchPosts = async () => {
    const {data, error} = await supabase
        .from("posts")
        .select("*")
        .order("created_at", {ascending: false}) // Posts Appear from latest to olderst

    if (error) throw new(error.message)

    return data
}

export default function PostList(){

    const {data, error, isLoading} = useQuery({
        queryKey: ["posts"],
        queryFn: fetchPosts
    });

    if (isLoading) return <div>Loading posts...</div>;

    if (error) {
        return <div>Error: {error.message}</div>
    }

    console.log(data);

    return(  // Default Case
        <div className="postlist-container">
            {/* Map through posts and display them */}
            {data?.map((post) => (
                <PostItem post={post} key={post.id} />
            ))}
        </div> 
    );
}