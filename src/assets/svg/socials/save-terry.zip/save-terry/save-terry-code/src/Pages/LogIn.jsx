import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from '/src/supabaseClient.js';

import loginImage from '/src/assets/login-image.jpeg';

import "./LogIn.css";

export default function LogIn() {

    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [message, setMessage] = useState("");

    const handleSubmit = async (event) => {
        event.preventDefault();
        setMessage("");

        const { data, error } = await supabase.auth.signInWithPassword({
            email: email,
            password: password,
        });

        if (error) {
            setMessage(error.message);

            setEmail("");
            setPassword("");
            return;
        }

        if (data) {
            navigate("/dashboard");
            return null;
        }

    }
    return (
        <div className="login-page">
            <div className="img-container">
                <img src={loginImage} alt="Login Image" />
            </div>
            <div className="login-container">
                <h2>Welcome Hero!</h2>
                <br />
                {message && <span>{message}</span>}
                <form onSubmit={handleSubmit}>
                    <label for="email">
                        Email
                    </label>
                    <input
                        id="email"
                        onChange={(e) => setEmail(e.target.value)}
                        value={email}
                        required
                        type="email" placeholder="yacine@gmail.com" />
                    <label for="password">
                        Password
                    </label>
                    <input
                        id="password"
                        required
                        onChange={(e) => setPassword(e.target.value)}
                        value={password}
                        type="password" placeholder="********" />
                    <button type="submit">Log in</button>
                </form>
                <span>New Here? </span>
                <Link to="/Register" id="register-link">Register</Link>
            </div>
        </div>
    );
}