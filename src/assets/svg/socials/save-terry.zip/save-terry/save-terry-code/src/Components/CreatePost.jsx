import { useState, useEffect, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "../supabaseClient";
import { useAuth } from "/src/context/AuthContext";

import './CreatePost.css'


const createPost = async (post, imageFile) => {


    const filePath = `${post.title}-${Date.now()}-${imageFile.name}`;

    const { error: uploadError } = await supabase.storage
        .from("post-images")
        .upload(filePath, imageFile);

    if (uploadError) {
        throw new Error(uploadError.message);
    }

    const { data: publicURLData } = supabase.storage
        .from("post-images")
        .getPublicUrl(filePath);


    const { data, error } = await supabase
        .from("posts")
        .insert([{...post, image_url: publicURLData.publicUrl}]);

    if (error) {
        throw new Error(error.message);
    }
    return data;
};

export default function CreatePost() {
    const [title, setTitle] = useState("");
    const [content, setContent] = useState("");
    const [selectedFile, setSelectedFile] = useState(null);
    const [profile, setProfile] = useState(null);

    const {user} = useAuth()

    useEffect(() => {
        if (user) {
            fetchProfile();
        }
    }, [user]);

    const fetchProfile = async () => {
        try {
            const { data, error } = await supabase.from('profile').select('*').eq('id', user.id).single();
            if (error && error.code === 'PGRST116') {
                // Profile doesn't exist, create it
                const { data: insertData, error: insertError } = await supabase.from('profile').insert([{ id: user.id }]).select().single();
                if (!insertError) {
                    setProfile(insertData);
                }
            } else if (!error) {
                setProfile(data);
            }
        } catch (err) {
            console.error('Error finding profile:', err);
        }
    };

    const { mutate, isPending, isError } = useMutation({
        mutationFn: (data) => {
            return createPost(data.post, data.imageFile);
        }
    });

    const handleSubmit = async (event) => {
        event.preventDefault(); // Prevent form from refreshing the page
        if (!selectedFile) return;
        mutate({ post: { title, content, avatar_url: profile?.avatar_url || null}, imageFile: selectedFile });
    }

    const handleFileChange = async (event) => {
        if (event.target.files && event.target.files[0]) {
            setSelectedFile(event.target.files[0]);
        }
    }

    return (
        <form className="create-post-form" onSubmit={handleSubmit}>
            <div>
                <label className="label-block">Title</label>
                <input type="text" id="title" required
                    onChange={(event) => setTitle(event.target.value)} />
            </div>
            <div>
                <label className="label-block">Content</label>
                <textarea type="text" id="Content" required rows={5}
                    onChange={(event) => setContent(event.target.value)} />
            </div>
            <div>
                <label>Upload Image</label>
                <input type="file" id="image" accept="image/*" required
                    onChange={handleFileChange} />
            </div>

            <button type="submit">
                {isPending ? "Creating..." : "Create Post"}
            </button>

            {isError && 
                <p style={{ color: 'red' }}
                >
                    Error creating post.
                </p>
            }
        </form>
    );
}
