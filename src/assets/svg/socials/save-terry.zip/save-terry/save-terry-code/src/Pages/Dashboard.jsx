import React, { useState, useEffect, useRef } from "react";
import { supabase } from '/src/supabaseClient.js';
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";

import { useAuth } from "/src/context/AuthContext";

import "./Dashboard.css"

export default function Dashboard() {
    const navigate = useNavigate();
    const { user } = useAuth();
    const profilePicRef = useRef();

    const [profile, setProfile] = useState(null);
    const [selectedProfileFile, setSelectedProfileFile] = useState(null);
    const [uploading, setUploading] = useState(false);
    const [deleting, setDeleting] = useState(false);
    const [toast, setToast] = useState('');
    const [showToast, setShowToast] = useState(false);

    const showToastMessage = (message) => {
        setToast(message);
        setShowToast(true);
        setTimeout(() => setShowToast(false), 3000);
    };

    useEffect(() => {
        if (user) {
            fetchProfile();
        }
    }, [user]);

    const fetchProfile = async () => {
        try {
            const { data, error } = await supabase.from('profile').select('*').eq('id', user.id).single();
            if (error && error.code === 'PGRST116') {
                const { data: insertData, error: insertError } = await supabase.from('profile').insert([{ id: user.id }]).select().single();
                if (!insertError) {
                    setProfile(insertData);
                }
            } else if (!error) {
                setProfile(data);
            }
        } catch (err) {
            console.error('Error fetching profile:', err);
        }
    };

    const handleUploadProfile = async () => {
        if (!selectedProfileFile) return;
        setUploading(true);
        const filePath = `${user.id}/${Date.now()}-${selectedProfileFile.name}`;
        const { error: uploadError } = await supabase.storage.from('avatars').upload(filePath, selectedProfileFile);
        if (uploadError) {
            alert('Upload failed: ' + uploadError.message);
            setUploading(false);
            return;
        }
        const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(filePath);
        const { error: updateError } = await supabase.from('profile').update({ avatar_url: publicUrl }).eq('id', user.id);
        if (updateError) {
            alert('Update failed: ' + updateError.message);
        } else {
            await fetchProfile();
            showToastMessage('Profile picture updated successfully!');
            setSelectedProfileFile(null);
            profilePicRef.current.value = '';
        }
        setUploading(false);
    };

    const handleDeleteProfile = async () => {
        if (!profile?.avatar_url) return;
        setDeleting(true);
        const { data: files, error: listError } = await supabase.storage.from('avatars').list(`${user.id}/`, { limit: 1000 });
        if (listError) {
            alert('List files failed: ' + listError.message);
            setDeleting(false);
            return;
        }
        if (files && files.length > 0) {
            const pathsToDelete = files.map(file => `${user.id}/${file.name}`);
            const { error: removeError } = await supabase.storage.from('avatars').remove(pathsToDelete);
            if (removeError) {
                alert('Delete files failed: ' + removeError.message);
                setDeleting(false);
                return;
            }
        }
        const { error: updateError } = await supabase.from('profile').update({ avatar_url: null }).eq('id', user.id);
        if (updateError) {
            alert('Update failed: ' + updateError.message);
        } else {
            await fetchProfile();
            alert('Profile picture deleted!');
        }
        setDeleting(false);
    };

    const signOut = async () => {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
        navigate("/login")
    }

    const displayName = user?.email
        ?.split("@")[0]
        ?.replace(/^\w/, c => c.toUpperCase());

    return (
        <div className="dashboard-container">
            {user ? (
                <div>
                    <h2>Hello, <span>{displayName}!</span></h2>

                    <div className="menu">
                        <Link to="/heros">
                            <button>Creations</button>
                        </Link>

                        <Link to="/create">
                            <button className="create">Create</button>
                        </Link>
                        <Link to="/dashboard">
                            <button>Profile</button>
                        </Link>

                    </div>
                    <button onClick={signOut} className="sign-out-button">Sign out</button>
                    <div className="dashboard-main">
                        <img src={profile?.avatar_url || '/assets/default-pfp.jpg'} alt="Profile" />

                        <div className="change-pfp">
                            <p>Change Profile Picture</p>
                            <label htmlFor="profile-pic-input" className="file-label">
                                {selectedProfileFile ? selectedProfileFile.name : 'Choose File'}
                            </label>
                            <input
                                id="profile-pic-input"
                                className="file-input"
                                ref={profilePicRef}
                                type="file"
                                accept="image/*"
                                onChange={(e) => setSelectedProfileFile(e.target.files[0])}
                                style={{display: 'none'}}
                            />

                            <button onClick={handleUploadProfile} disabled={!selectedProfileFile || uploading}>{uploading ? 'Uploading...' : 'Upload'}</button>

                            <button className="delete-pfp" onClick={handleDeleteProfile} disabled={!profile?.avatar_url || deleting}>{deleting ? 'Deleting...' : 'Delete'}</button>

                        </div>
                    </div>
                </div>

            ) :
                <Link to="/login">
                    <button>LogIn</button>
                </Link>
            }
            {showToast && <div className="toast">{toast}</div>}
        </div>
    );
}
