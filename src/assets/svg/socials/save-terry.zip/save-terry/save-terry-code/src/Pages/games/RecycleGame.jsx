// src/pages/games/RecycleGame.jsx
import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import "./RecycleGame.css";
import wallBg from "/src/assets/wall.png";
import landfill from "/src/assets/landfill.png";
import redBin from "/src/assets/red.png";
import blueBin from "/src/assets/blue.png";
import greenBin from "/src/assets/green.png";
import yellowBin from "/src/assets/yellow.png";
import mockup from "/src/assets/mockup.png";
import yayRecycle from "/src/assets/yay-scorecard.png";
import nayRecycle from "/src/assets/nay-scorecard.png";

import yaySound from "/src/assets/sounds/yay-sound.mp3";

import { ITEMS } from "/src/data/itemsData.js";
import ConveyorItem from "/src/Components/ConveyorItem";
import { DndContext, useDroppable } from "@dnd-kit/core";

import Bin from "/src/Components/Bin";

export default function RecycleGame() {
  const [items, setItems] = useState([]);
  const [draggedId, setDraggedId] = useState(null); // Track currently dragged item ID used to stop the animation of the dragged item
  const [started, setStarted] = useState(false); // Add game start state
  const [score, setScore] = useState(0);
  const [trials, setTrials] = useState(3); // Number of trials/lives
  const [showYay, setShowYay] = useState(false);
  const yayAudioRef = useRef(null);
  const [nayCount, setNayCount] = useState(0); // Track incorrect sorts
  const [isVibrating, setIsVibrating] = useState(false); // State for screen vibration
  const [showGameOver, setShowGameOver] = useState(false); // State for game over screen
  const [maxScore, setMaxScore] = useState(() => {
    const storedMaxScore = localStorage.getItem('maxScore');

    return storedMaxScore ? parseInt(storedMaxScore, 10) : 0;
  });
  const [isPaused, setIsPaused] = useState(false);

  const conveyorWidth = 960; // Width of the conveyor area

  const { setNodeRef } = useDroppable({
    id: "items-container",
  });

  //The dnd library requires unique ids for each draggable item
  useEffect(() => {
    let uniqueId = 0; // Add a counter for unique IDs

    const interval = setInterval(() => {
      const randomItem = ITEMS[Math.floor(Math.random() * ITEMS.length)];
      uniqueId++; // Increment for each new item

      setItems(prev => [
        ...prev,
        {
          ...randomItem,
          left: conveyorWidth,
          id: `${randomItem.id}-${uniqueId}` // Make the id unique
        }
      ]);
    }, 1500);

    return () => clearInterval(interval);
  }, []);


  useEffect(() => {
    let animationFrame;

    const moveItems = () => {
      if (!isPaused) {
        setItems(prev =>
          prev
            .map(item =>
              item.id === draggedId
                ? item
                : { ...item, left: item.left - 2 }
            )
            .filter(item => item.left + item.width > 0)
        );
      }

      animationFrame = requestAnimationFrame(moveItems);
    };

    animationFrame = requestAnimationFrame(moveItems);

    return () => cancelAnimationFrame(animationFrame);
  }, [draggedId, isPaused]);


  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === "hidden") {
        setIsPaused(true);
      } else {
        setIsPaused(false);
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);

    return () => {
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, []);

  function handleDragEnd(event) {
    const { active, over } = event;
    console.log("DragEnd over:", over);
    if (!over) return;

    const draggedItem = items.find(item => item.id === active.id);
    if (!draggedItem) return;

    const itemType = draggedItem.type;
    const binType = over.id;

    const validBins = ["plastic", "paper", "metal", "bread"];
    if (validBins.includes(binType)) {
      setItems(prev => prev.filter(item => item.id !== active.id));
      if (itemType === binType) {
        setScore(prev => prev + 1); // <-- update score state
        setShowYay(true); // Show yay image
        yayAudioRef.current = new Audio(yaySound);
        yayAudioRef.current.play();
        setTimeout(() => {
          setShowYay(false);
          if (yayAudioRef.current) {
            yayAudioRef.current.pause();
            yayAudioRef.current.currentTime = 0;
            yayAudioRef.current = null;
          }
        }, 1200);
        console.log("Yaaaaay Correctly sorted:", active.id);

      } else {
        console.log("Incorrectly sorted:", active.id);
        setTrials(prev => prev - 1);
        setNayCount(prev => prev + 1); // Increment nay count
        setIsVibrating(true); // Start vibration
        setTimeout(() => setIsVibrating(false), 200); // Stop vibration after 200ms (matching CSS animation duration)
        if (window.navigator.vibrate) {
          window.navigator.vibrate(300); // vibrate for 300ms
        }
        if (trials - 1 <= 0) {
          setShowGameOver(true); // Show game over screen
          if (score > maxScore) {
            setMaxScore(score);
            localStorage.setItem('maxScore', score.toString());
          }
          // Reset game state (will be done when restarting from game over screen)
        }
      }
    }
  }

  const resetGame = () => {
    setScore(0);
    setTrials(3);
    setItems([]);
    setStarted(false);
    setNayCount(0);
    setShowGameOver(false);
    setStarted(true);
  };

  return (
    <div className="recycle-game-everything-container">
      <div className={`recycle-game-container 
    ${isVibrating ? "vibrate-screen" : ""}
    ${isPaused ? "paused-when-hidden" : ""}`}>
        <div className="breadcrumb-trail">
          <p><Link to="/Games" id="games-link">Games</Link> &gt; Recycle Game</p>
        </div>
        <h2>Help Terry Sort the Trash!</h2>
        {!started ? (
          <div className="start-screen">

            <img src={mockup} alt="Mockup Background" />
            <button
              className="play-button-start-screen-recycle"
              onClick={() => setStarted(true)}
            >
              Play
            </button>
          </div>
        ) : showGameOver ? (
          <div className="game-over-screen">

            <div className="game-over-screen-inside">
              <p className="h3-replace">Game Over!</p>
              <p>Your final score is {score}.</p>
              <p>Max Score: {maxScore}</p>
              <button onClick={resetGame}>Play Again</button>
            </div>

          </div>
        ) : (
          <>
            {showYay && (
              <img
                src={yayRecycle}
                alt="Yay! Correctly sorted!"
                style={{
                  position: "absolute",
                  height: "50px",
                  width: "50px",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                  zIndex: 100,
                  pointerEvents: "none"
                }}
              />
            )}

            <div id="game-container">
              <img src={wallBg} id="wall-bg" alt="Wall Background" />
              <DndContext
                onDragStart={event => setDraggedId(event.active.id)}
                onDragEnd={event => {
                  setDraggedId(null);
                  handleDragEnd(event);
                }}
              >
                <div
                  ref={setNodeRef}
                  className={`items-container${draggedId ? " dragging" : ""}`}
                >
                  {items.map((item, index) => (
                    <ConveyorItem
                      key={index}
                      itemData={item}
                      style={{ left: item.left }}
                    />
                  ))}
                </div>
                <div className="conveyor-container">
                  <div className="conveyor"></div>
                  <div className="conveyor-ext"></div>
                  <div className="conveyor-ext"></div>
                  <div className="conveyor-ext"></div>
                  <div className="conveyor"></div>
                  <div className="conveyor-ext"></div>
                  <div className="conveyor-ext"></div>
                  <div className="conveyor-ext"></div>
                  <div className="conveyor"></div>
                  <div className="conveyor-ext"></div>
                  <div className="conveyor-ext"></div>
                  <div className="conveyor-ext"></div>
                  <div className="conveyor"></div>
                  <div className="conveyor-ext"></div>
                  <div className="conveyor-ext"></div>
                </div>
                <img src={landfill} id="landfill" alt="Landfill" />
                <div id="score">
                  Score: {score}
                </div>

                <div className="bins-container">
                  <Bin id="plastic" src={redBin} alt="Plastic" />
                  <Bin id="paper" src={blueBin} alt="Paper" />
                  <Bin id="metal" src={greenBin} alt="Metal" />
                  <Bin id="bread" src={yellowBin} alt="Bread" />
                </div>
              </DndContext>
            </div>
            <div style={{
              position: "absolute",
              bottom: "-50px",
              left: "35%",
              transform: "translateX(-50%)",
              display: "flex",
              gap: "10px",
              zIndex: 200
            }}>
              {Array.from({ length: nayCount }).map((_, i) => (
                <img
                  key={i}
                  src={nayRecycle}
                  alt="Incorrect sort"
                  style={{ width: "50px", height: "50px" }}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
