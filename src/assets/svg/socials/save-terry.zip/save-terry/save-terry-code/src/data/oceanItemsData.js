export const OCEAN_ITEMS = [
  { x: 0,   width: 17, height: 64},
  { x: 18,  width: 25, height: 64},
  { x: 44,  width: 19, height: 64},
  { x: 63,  width: 41, height: 64},
  { x: 105, width: 48, height: 64},
  { x: 155, width: 48, height: 64},
  { x: 203, width: 38, height: 64},
  { x: 245, width: 44, height: 64},
];
