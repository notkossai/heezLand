import Lottie from "lottie-react";
import recycleAnimation from "/src/animations/recycle-animation.json";

export default function RecycleAnimation() {
  return (
    <div style={{ width: "500px" }}>
      <Lottie animationData={recycleAnimation} loop={true} />
    </div>
  );
}
