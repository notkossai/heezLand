import CreatePost from "/src/Components/CreatePost";
import { Link } from "react-router-dom";

import "./CreatePostPage.css"


export default function CreatePostPage() {
    return (
        <div className="create-post">
            <div className="menu">
                <Link to="/heros">
                    <button>Creations</button>
                </Link>

                <Link to="/create">
                    <button className="create">Create</button>
                </Link>
                <Link to="/dashboard">
                    <button>Profile</button>
                </Link>

            </div>
            <div className="create-post-page">
                <h2>Create New Post</h2>
                <CreatePost />
            </div>
        </div>
    );
}