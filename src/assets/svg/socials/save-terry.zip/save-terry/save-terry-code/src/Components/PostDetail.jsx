import { useQuery } from "@tanstack/react-query";
import { supabase } from "/src/supabaseClient"


import LikeButton from "/src/Components/LikeButton.jsx";

import './PostDetail.css'

const fetchPostById = async (id) => {
        const {data, error} = await supabase
            .from("posts")
            .select("*")
            .eq("id", id)
            .single();
    
        if (error) throw new(error.message)
    
        return data
    }

export default function PostDetail({ postId }) {

    const {data, error, isLoading} = useQuery({
        queryKey: ["post", postId],
        queryFn: () => fetchPostById(postId)
    });

    if (isLoading) return <div>Loading posts...</div>;

    if (error) {
        return <div>Error: {error.message}</div>
    }


    return(
        <div className="post-detail-container">
            <h2>{data?.title}</h2>
            <img src={data?.image_url} alt={data?.title} />
            <p className="content-paragraph">{data?.content}</p>
            <p className="post-date">Posted on: {new Date(data.created_at).toLocaleDateString()}</p>

            <LikeButton postId={postId} />
        </div>
    );
}