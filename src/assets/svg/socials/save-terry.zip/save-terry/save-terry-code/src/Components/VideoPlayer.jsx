import { motion } from 'motion/react';
import { Play } from 'lucide-react';
import { useState } from 'react';
import './VideoPlayer.css';

export function VideoPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div className="video-player">
      {/* Video removed */}
      
      {/* Decorative corner elements */}
      <div className="corner corner-top-left" />
      <div className="corner corner-top-right" />
      <div className="corner corner-bottom-left" />
      <div className="corner corner-bottom-right" />
    </div>
  );
}
