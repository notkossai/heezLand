import React from "react";
import { ITEMS } from "/src/data/itemsData.js";
import sprite from "/src/assets/recycle-items-bread-final.png";
import { useDraggable } from "@dnd-kit/core";

export default function ConveyorItem({ itemData, style }) {

  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: itemData.id,
  });

  const dragStyle = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
  } : {};

  return (
    <div
      ref={setNodeRef}
      data-id={itemData.id}
      {...listeners}
      {...attributes}
      className="recycle-item"
      style={{
        width: itemData.width,
        height: itemData.height,
        backgroundImage: `url(${sprite})`,
        backgroundRepeat: "no-repeat",
        backgroundPositionX: `-${itemData.x}px`,
        position: "absolute",
        ...style,
        ...dragStyle,
      }}
    />
  );
}
