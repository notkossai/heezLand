// src/pages/Games.jsx
import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Games.css";
import recyclePreview from "/src/assets/recyclePreview.png";
import oceanCleanerPreview from "/src/assets/oceanCleanerPreview.png";

export default function Games() {
  const [toast, setToast] = useState('');
  const [showToast, setShowToast] = useState(false);

  const handleGameClick = (e) => {
    if (window.innerWidth <= 480) {
      e.preventDefault();
      setToast('Please use a laptop to Play');
      setShowToast(true);
      setTimeout(() => setShowToast(false), 3000);
    }
  };
  return (
    <div className="games-page">
      <h2>🎮 Games Center</h2>
      <p className="play-discover">Play, Discover and Learn!</p>

      <div className="games-grid">
        <Link to="/games/recycle" className="game-card" onClick={handleGameClick}>
          <p className="h3-replace-games-page">Recycle Sorter</p>
          <img src={recyclePreview} alt="Recycle Game Preview" />
        </Link>

        <Link to="/games/clean-ocean" className="game-card" onClick={handleGameClick}>
          <p className="h3-replace-games-page">Ocean Cleaner</p>
          <img src={oceanCleanerPreview} alt="Ocean Cleaner Preview" />

        </Link>
      </div>
      {showToast && <div className="toast-games-mobile">{toast}</div>}
    </div>
  );
}
