import { useDroppable } from "@dnd-kit/core";

export default function Bin({ id, src, alt }) {
  const { setNodeRef } = useDroppable({ id });
  return (
    <div ref={setNodeRef} style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
      <img src={src} className="bin" alt={alt} />
      <p
      style={{
        fontFamily: "'GamePaused', sans-serif",
        position: "absolute",
        bottom: "-20px",
        color: "black",
      }}
      >{alt}</p>
    </div>
  );
}