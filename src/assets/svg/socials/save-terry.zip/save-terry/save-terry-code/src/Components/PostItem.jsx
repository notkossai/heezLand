import { Link } from "react-router-dom";

import "./PostItem.css"

export default function PostItem({post}){
    return(
        <div className="postItem-container">
            <Link to={`/post/${post.id}`}>
                <div>
                    {/* Header: Avatar and Title */}
                    <div className="post-header">
                        <div>
                            <img
                                src={post.avatar_url || "/assets/default-pfp.jpg"}
                                alt="User Avatar"
                                style={{ width: '40px', height: '40px', borderRadius: '50%' }}
                            />
                        </div>
                        <div className="title">
                            <div>{post.title}</div>
                        </div>
                    </div>
                </div>

                {/* Image Banner */}
                <div className="post-banner">
                    <img src={post.image_url} alt={post.title} />
                </div>
            </Link>
        </div>
    );
}
