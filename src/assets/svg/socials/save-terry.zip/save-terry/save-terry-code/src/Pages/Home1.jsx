import { Link } from "react-router-dom"
import { motion } from 'motion/react';
import { Recycle, Leaf, Globe, Divide } from 'lucide-react';
import { VideoPlayer } from '/src/Components/VideoPlayer';
import { FloatingElement } from '/src/Components/FloatingElement';
import { useRef, useState, useEffect } from "react";

import sadTerry from "/src/assets/sad-terry.webm";
import happyTerry from "/src/assets/happy-terry.webm";
import heroTerry from "/src/assets/hero-terry.mp4";
import terryTalk from "/src/assets/sounds/terry-talk.mp3";
import saveAnimals from "/src/assets/save-animals.png";
import saveTrees from "/src/assets/save-trees.jpg";
import cleanPlaygrounds from "/src/assets/clean-playgrounds.jpg";
import RecycleAnimation from "/src/Components/RecycleAnimation.jsx";

import { homeTranslations } from "/src/translations/HomeTranslations";

import '../fonts.css';
import './Home1.css';



export default function Home1({ language }) {
  const t = homeTranslations[language]; // current language

  const sadTerryRef = useRef(null);
  const [isHovering, setIsHovering] = useState(false); // State to track hover status

  const audioRef = useRef(null);

  useEffect(() => {
    // Stop audio when navigating away or unmounting
    return () => {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    };
  }, []);

  // Initialize the Audio object once
  if (!audioRef.current) {
    audioRef.current = new Audio(terryTalk);
  }

  const handleMouseEnter = (vidRef) => {
    setIsHovering(true);
    if (vidRef.current) {
      vidRef.current.currentTime = 0; // restart from beginning
      vidRef.current.play(); // Play the video when hoveringnt) 


    }
    audioRef.current.currentTime = 0; // Reset sound to beginning
    audioRef.current.play().catch(err => {
      console.log("Audio blocked:", err);
    });

  }

  return (
    <div className={`${language === 'AR' ? 'arabic-container' : ''}`}>
      <div className="app-container">
        {/* Background Decorative Eleents */}
        <div className="background-elements">
          {/* Storybook-style hills */}
          <div className="hills-layer-1">
            <svg className="hill-svg" viewBox="0 0 1440 320" preserveAspectRatio="none">
              <path
                fill="#d4fld4"
                fillOpacity="0.6"
                d="M0,160L48,149.3C96,139,192,117,288,122.7C384,128,480,160,576,165.3C672,171,768,149,864,144C960,139,1056,149,1152,138.7C1248,128,1344,96,1392,80L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
              ></path>
            </svg>
          </div>

          <div className="hills-layer-2">
            <svg className="hill-svg-small" viewBox="0 0 1440 320" preserveAspectRatio="none">
              <path
                fill="#b8e6b8"
                fillOpacity="0.4"
                d="M0,224L48,213.3C96,203,192,181,288,186.7C384,192,480,224,576,229.3C672,235,768,213,864,208C960,203,1056,213,1152,202.7C1248,192,1344,160,1392,144L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
              ></path>
            </svg>
          </div>

          {/* Faint circular recycling patterns */}
          <motion.div
            className="recycle-pattern-1"
            animate={{ rotate: 360 }}
            transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          >
            <Recycle className="icon-large-green" />
          </motion.div>

          <motion.div
            className="recycle-pattern-2"
            animate={{ rotate: -360 }}
            transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
          >
            <Recycle className="icon-medium-blue" />
          </motion.div>

          <motion.div
            className="globe-pattern-1"
            animate={{ rotate: 360 }}
            transition={{ duration: 45, repeat: Infinity, ease: "linear" }}
          >
            <Globe className="icon-large-teal" />
          </motion.div>

          {/* Abstract eco shapes */}
          <motion.div
            className="eco-shape-1"
            animate={{ y: [0, -20, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          />

          <motion.div
            className="eco-shape-2"
            animate={{ y: [0, -15, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          />

          <motion.div
            className="eco-shape-3"
            animate={{ y: [0, -25, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          />
        </div>

        {/* Floating animated leaves */}
        <FloatingElement delay={0} duration={12} startX="10%" startY="-10%">
          <Leaf className="leaf-icon-1" />
        </FloatingElement>

        <FloatingElement delay={2} duration={15} startX="80%" startY="-10%">
          <Leaf className="leaf-icon-2" />
        </FloatingElement>

        <FloatingElement delay={4} duration={18} startX="30%" startY="-10%">
          <Leaf className="leaf-icon-3" />
        </FloatingElement>

        <FloatingElement delay={6} duration={14} startX="60%" startY="-10%">
          <Leaf className="leaf-icon-4" />
        </FloatingElement>

        <FloatingElement delay={8} duration={16} startX="45%" startY="-10%">
          <Leaf className="leaf-icon-5" />
        </FloatingElement>



        {/* Small recycling icons scattered */}
        <motion.div
          className="small-recycle-1"
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        >
          <Recycle className="icon-small-green" />
        </motion.div>

        <motion.div
          className="small-recycle-2"
          animate={{ rotate: [0, -10, 10, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        >
          <Recycle className="icon-small-blue" />
        </motion.div>

        <motion.div
          className="small-globe-1"
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        >
          <Globe className="icon-small-teal" />
        </motion.div>

        {/* Main Content */}
        <div className={`main-content ${language === 'AR' ? 'arabic-layout' : ''}`}>
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="header-section"
          >
          </motion.div>

          {/* Central Video Area */}

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="video-container"
          >
            <video
              ref={sadTerryRef}
              onMouseEnter={() => (handleMouseEnter(sadTerryRef))}
              width="480" height="400" muted
            >
              <source src={sadTerry} type="video/webm" />
              Your browser does not support the video tag.
            </video>
          </motion.div>

          <div className="terry-message">
            <div className="main-message-container main-message-container-home">
              <h1>{t.mainH1}</h1>
              <div className="h2-container h2-container-home">
                {t.h2Words.map((word, index) => (
                  <h2 key={index}>{word}</h2>
                ))}
              </div>
            </div>


            <Link to="/Games" >
              <button className="games-button games-button-home">{t.saveTerry}</button>
            </Link>
          </div>
        </div>
      </div>
      <div className="why-recycling">
        <h2>{t.whyRecycling}</h2>
        <div className="recycling-points-container">
          {t.points.map((point, index) => (
            <div key={index} className="recycling-point"
              id={
                index === 0
                  ? "save-animals-point"
                  : index === 1
                    ? "save-trees-point"
                    : "clean-playgrounds-point"
              }
            >
              <img
                src={
                  index === 0
                    ? saveAnimals
                    : index === 1
                      ? saveTrees
                      : cleanPlaygrounds
                }
                alt={point}
              />
              <div className="reason-container">
                <p className="h3-replace-home">{point}</p>
              </div>
            </div>
          ))}
          <Link to="/Books" className="learn-more-link">
            <button className="learn-more-button">{t.learnMore}</button>
          </Link>
        </div>




      </div>
      <div className="wave-container"></div>
      <div className={`eco-hero ${language === 'AR' ? 'arabic-container' : ''}`}>
        <h2>{t.ecoHeroTitle}</h2>
        <div className="eco-hero-container">
          <div className="eco-hero-text">
            <p>{t.ecoHeroText}</p>
            <Link to="/heros">
              <button className="become-hero">{t.ecoHeroButton}</button>
            </Link>
            
          </div>
          <div className="recycle-animation">
            <RecycleAnimation />
          </div>
        </div>
      </div>
    </div>
  );
}
