import { Link, useNavigate } from "react-router-dom";
import PostList from "/src/Components/PostList";
import { useAuth } from '/src/context/AuthContext';

import { motion } from 'motion/react';
import { FloatingElement } from '/src/Components/FloatingElement';
import { Recycle, Leaf, Globe } from 'lucide-react';
import { supabase } from '/src/supabaseClient.js';

import "./Heros.css"

export default function Heros() {
    const navigate = useNavigate();
    const { user } = useAuth();

    const signOut = async () => {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
        navigate("/login")
    }

    return (
        <div className="heros-container">
            {/* Background Decorative Elements */}
            <div className="background-elements">


                {/* Faint circular recycling patterns */}
                <motion.div
                    className="recycle-pattern-1"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
                >
                    <Recycle className="icon-large-green" />
                </motion.div>

                <motion.div
                    className="recycle-pattern-2"
                    animate={{ rotate: -360 }}
                    transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
                >
                    <Recycle className="icon-medium-blue" />
                </motion.div>

                <motion.div
                    className="globe-pattern-1"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 45, repeat: Infinity, ease: "linear" }}
                >
                    <Globe className="icon-large-teal" />
                </motion.div>

                {/* Abstract eco shapes */}
                <motion.div
                    className="eco-shape-1"
                    animate={{ y: [0, -20, 0] }}
                    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                />

                <motion.div
                    className="eco-shape-2"
                    animate={{ y: [0, -15, 0] }}
                    transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                />

                <motion.div
                    className="eco-shape-3"
                    animate={{ y: [0, -25, 0] }}
                    transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 2 }}
                />
            </div>

            {/* Floating animated leaves */}
            <FloatingElement delay={0} duration={12} startX="10%" startY="-10%">
                <Leaf className="leaf-icon-1" />
            </FloatingElement>

            <FloatingElement delay={2} duration={15} startX="80%" startY="-10%">
                <Leaf className="leaf-icon-2" />
            </FloatingElement>

            <FloatingElement delay={4} duration={18} startX="30%" startY="-10%">
                <Leaf className="leaf-icon-3" />
            </FloatingElement>

            <FloatingElement delay={6} duration={14} startX="60%" startY="-10%">
                <Leaf className="leaf-icon-4" />
            </FloatingElement>

            <FloatingElement delay={8} duration={16} startX="45%" startY="-10%">
                <Leaf className="leaf-icon-5" />
            </FloatingElement>



            {/* Small recycling icons scattered */}
            <motion.div
                className="small-recycle-1"
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            >
                <Recycle className="icon-small-green" />
            </motion.div>

            <motion.div
                className="small-recycle-2"
                animate={{ rotate: [0, -10, 10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            >
                <Recycle className="icon-small-blue" />
            </motion.div>

            <motion.div
                className="small-globe-1"
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 2 }}
            >
                <Globe className="icon-small-teal" />
            </motion.div>


            {/*Main Content*/}
            <div className="main-content">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    className="header-section"
                >
                </motion.div>
                <h2>Heros Page</h2>
                <h3>Recent Posts</h3>
                <div className="menu-feed">
                    <div className="menu" id="menu-heros-page">
                        <Link to="/heros">
                            <button>Creations</button>
                        </Link>
                        
                        <Link to="/create">
                            <button className="create">Create</button>
                        </Link>
                        <Link to="/dashboard">
                            <button>{user ? 'Profile' : 'Join Heros'}</button>
                        </Link>
                        
                    </div>

                    <div>
                        <PostList />
                    </div>
                </div>

            </div>



        </div>

    );
}
