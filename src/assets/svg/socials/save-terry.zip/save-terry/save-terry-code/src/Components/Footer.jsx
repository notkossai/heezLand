import React from "react";
import "./Footer.css";
import githubImg from "/src/assets/github.png"
import saveTerryLogo from "/src/assets/icons/save-terry-final.png"

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-section footer-brand">
          <div className="footer-logo">
            <span><img src={saveTerryLogo} alt="Save Terry Logo" /></span>
          </div>
          <div>
            <p className="footer-title">Save Terry</p>
            <p className="footer-subtitle">A kid‑friendly place to learn and share about recycling.</p>
          </div>
        </div>

        <nav className="footer-links">
          <a href="/">Home</a>
          <a href="/games">Games</a>
          <a href="/books">Books</a>
          <a href="/heros">Community</a>
        </nav>

        <div className="footer-actions">
          <div className="footer-socials">
            <a href="https://github.com/AsmaNord" id="github"><img src={githubImg} alt="Github" /></a>
            <a href="asmaelmokretar19@gmail.com" aria-label="Email">📬</a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Save Terry. All rights reserved.</p>
        <div className="footer-bottom-links">
        </div>
      </div>
    </footer>
  );
}
