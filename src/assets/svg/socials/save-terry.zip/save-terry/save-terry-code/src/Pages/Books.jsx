import React from "react";
import "./Books.css";

import { useEffect, useState } from 'react';
import { supabase } from '/src/supabaseClient';
import { FloatingElement } from '/src/Components/FloatingElement';
import { motion } from 'motion/react';
import { Recycle, Leaf, Globe } from 'lucide-react';

import img0 from '/src/assets/every-day-is-earth-day.png';
import img1 from '/src/assets/recycle-and-remke.png'
import img2 from '/src/assets/the-adventures-of-a-plastic-bottle.png'

const booksImages = [img0, img1, img2];

export default function Books() {

    const [files, setFiles] = useState([]);

    useEffect(() => {
        const fetchFiles = async () => {
            const { data, error } = await supabase
                .storage
                .from('books')
                .list('', { limit: 100, offset: 0 });

            if (error) {
                console.error('Error fetching files:', error);
            } else {
                // Map files to include public URLs
                const filesWithUrls = data.map(file => ({
                    name: file.name,
                    url: "https://qlduwvanpivxyhaolgjr.supabase.co/storage/v1/object/public/books/" + encodeURIComponent(file.name)
                }));

                setFiles(filesWithUrls);
            }
        };

        fetchFiles();
    }, []);


    return (
        <>
            <div className="app-container">
                {/* Background Decorative Elements */}
                <div className="background-elements">
                    {/* Storybook-style hills */}
                    <div className="hills-layer-1">
                        <svg className="hill-svg" viewBox="0 0 1440 320" preserveAspectRatio="none">
                            <path
                                fill="#d4fld4"
                                fillOpacity="0.6"
                                d="M0,160L48,149.3C96,139,192,117,288,122.7C384,128,480,160,576,165.3C672,171,768,149,864,144C960,139,1056,149,1152,138.7C1248,128,1344,96,1392,80L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
                            ></path>
                        </svg>
                    </div>

                    <div className="hills-layer-2">
                        <svg className="hill-svg-small" viewBox="0 0 1440 320" preserveAspectRatio="none">
                            <path
                                fill="#b8e6b8"
                                fillOpacity="0.4"
                                d="M0,224L48,213.3C96,203,192,181,288,186.7C384,192,480,224,576,229.3C672,235,768,213,864,208C960,203,1056,213,1152,202.7C1248,192,1344,160,1392,144L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
                            ></path>
                        </svg>
                    </div>

                    {/* Faint circular recycling patterns */}
                    <motion.div
                        className="recycle-pattern-1"
                        animate={{ rotate: 360 }}
                        transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
                    >
                        <Recycle className="icon-large-green" />
                    </motion.div>

                    <motion.div
                        className="recycle-pattern-2"
                        animate={{ rotate: -360 }}
                        transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
                    >
                        <Recycle className="icon-medium-blue" />
                    </motion.div>

                    <motion.div
                        className="globe-pattern-1"
                        animate={{ rotate: 360 }}
                        transition={{ duration: 45, repeat: Infinity, ease: "linear" }}
                    >
                        <Globe className="icon-large-teal" />
                    </motion.div>

                    {/* Abstract eco shapes */}
                    <motion.div
                        className="eco-shape-1"
                        animate={{ y: [0, -20, 0] }}
                        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                    />

                    <motion.div
                        className="eco-shape-2"
                        animate={{ y: [0, -15, 0] }}
                        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                    />

                    <motion.div
                        className="eco-shape-3"
                        animate={{ y: [0, -25, 0] }}
                        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 2 }}
                    />
                </div>

                {/* Floating animated leaves */}
                <FloatingElement delay={0} duration={12} startX="10%" startY="-10%">
                    <Leaf className="leaf-icon-1" />
                </FloatingElement>

                <FloatingElement delay={2} duration={15} startX="80%" startY="-10%">
                    <Leaf className="leaf-icon-2" />
                </FloatingElement>

                <FloatingElement delay={4} duration={18} startX="30%" startY="-10%">
                    <Leaf className="leaf-icon-3" />
                </FloatingElement>

                <FloatingElement delay={6} duration={14} startX="60%" startY="-10%">
                    <Leaf className="leaf-icon-4" />
                </FloatingElement>

                <FloatingElement delay={8} duration={16} startX="45%" startY="-10%">
                    <Leaf className="leaf-icon-5" />
                </FloatingElement>



                {/* Small recycling icons scattered */}
                <motion.div
                    className="small-recycle-1"
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                >
                    <Recycle className="icon-small-green" />
                </motion.div>

                <motion.div
                    className="small-recycle-2"
                    animate={{ rotate: [0, -10, 10, 0] }}
                    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                >
                    <Recycle className="icon-small-blue" />
                </motion.div>

                <motion.div
                    className="small-globe-1"
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 2 }}
                >
                    <Globe className="icon-small-teal" />
                </motion.div>

                {/* Main Content */}
                <div className="main-content">
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                        className="header-section"
                    >
                    </motion.div>
                </div>
                <div className="books-page">
                    <h2>Your Get Smarter Library</h2>
                    <ul className="books-grid">
                        {files.map((file, index) => (
                            <li key={file.name} className="book-item">

                                <span>{file.name}</span>
                                <a href={file.url + "#toolbar=0"} target="_blank" rel="noopener noreferrer" className="tooltip">
                                    <button>Read</button>
                                    <span className="tooltip-text">Click to View or Download the file</span>
                                </a>
                                <a href={file.url + "#toolbar=0"} target="_blank" rel="noopener noreferrer">
                                    <img src={booksImages[index]} alt={`Image for ${file.name}`} />
                                </a>

                            </li>
                        ))}
                    </ul>
                </div>
            </div>

        </>

    )
}