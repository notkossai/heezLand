export const homeTranslations = {
  EN: {
    mainH1: "RE",
    h2Words: ["USE", "DUCE", "CYCLE"],
    whyRecycling: "Why Recycling Matters!",
    points: [
      "Helps Animals Stay Safe",
      "Saves Energy and Trees",
      "Cleaner Playgrounds"
    ],
    learnMore: "Learn More!",
    saveTerry: "Save Terry!",
    ecoHeroTitle: "Join the Eco Heroes!",
    ecoHeroText: "Be a part of the solution and help us make a real difference for our planet.\nEvery action counts!",
    ecoHeroButton: "Become a Hero"
  },
  FR: {
    mainH1: "RE",
    h2Words: ["UTILISE", "RÉDUIS", "RECYCLE"],
    whyRecycling: "Pourquoi le recyclage est important !",
    points: [
      "Protège les animaux",
      "Économise l'énergie et les arbres",
      "Aires de jeux plus propres"
    ],
    learnMore: "En savoir plus !",
    saveTerry: "Sauvez Terry !",
    ecoHeroTitle: "Rejoignez les Éco-Héros !",
    ecoHeroText: "Faites partie de la solution et aidez-nous à faire une réelle différence pour notre planète.\nChaque action compte !",
    ecoHeroButton: "Devenir un Hero"
  },
  AR: {
    mainH1: "إعادة",
    h2Words: ["الاستخدام", "التدوير"],
    whyRecycling: "لماذا إعادة التدوير مهمة!",
    points: [
      "حماية الحيوانات",
      "توفير الطاقة والأشجار",
      "حدائق وملاعب أنظف"
    ],
    learnMore: "اعرف المزيد!",
    saveTerry: "أنقذ تيري!",
    ecoHeroTitle: "انضم إلى أبطال البيئة!",
    ecoHeroText: "كن جزءًا من الحل وساعدنا في إحداث فرق حقيقي لكوكبنا.\nكل عمل مهم!",
    ecoHeroButton: "كن بطلاً"
  }
};
