import { useState } from "react";
import Home1 from "./Pages/Home1";
import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Nav from "./Components/Nav";
import Footer from "./Components/Footer"
import { AuthProvider } from "/src/context/AuthContext";
import Games from "./Pages/Games";
import Books from "./Pages/Books";
import Register from "./Pages/Register";
import LogIn from "./Pages/LogIn";
import Dashboard from "./Pages/Dashboard";
import Heros from "./Pages/Heros";
import CreatePostPage from "./Pages/CreatePostPage";
import RecycleGame from "./Pages/games/RecycleGame";
import CleanOcean from "./Pages/games/CleanOcean";
import PostPage from "./Pages/PostPage";

import Wrapper from "./Components/Wrapper"

export default function App() {
  const [language, setLanguage] = useState("EN"); // default language

  return (
    <AuthProvider>
      <BrowserRouter>
        <Nav language={language} setLanguage={setLanguage} />
        <Routes>
          <Route path="/" element={<Home1 language={language} />} />
          <Route path="/games" element={<Games language={language} />} />
          <Route path="/games/recycle" element={<RecycleGame language={language} />} />
          <Route path="/games/clean-ocean" element={<CleanOcean language={language} />} />
          <Route path="/books" element={<Books language={language} />} />
          <Route path="/register" element={<Register language={language} />} />
          <Route path="/login" element={<LogIn language={language} />} />
          <Route path="/heros" element={<Heros language={language} />} />
          <Route path="/post/:id" element={<PostPage language={language} />} />

          {/* Protected pages */}
          <Route path="/dashboard" element={
            <Wrapper>
              <Dashboard language={language} />
            </Wrapper>}
          />
          <Route path="/create" element={
            <Wrapper>
              <CreatePostPage language={language} />
            </Wrapper>}
          />
        </Routes>
        <Footer />
      </BrowserRouter>
    </AuthProvider>

  );
}