import React, { useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from '/src/supabaseClient.js';

import RecyclingHero from '/src/assets/recycling-hero-register.jpg'

import "./Register.css";

export default function Register() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [message, setMessage] = useState("");
    const [emailError, setEmailError] = useState(false);
    const [passwordError, setPasswordError] = useState(false);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setMessage("");

        const { data, error } = await supabase.auth.signUp({
            email: email,
            password: password,
        });

        if (error) {
            setMessage(error.message);
            const lowerMessage = error.message.toLowerCase();
            if (lowerMessage.includes('password')) {
                setPasswordError(true);
            } else if (lowerMessage.includes('email') || lowerMessage.includes('already') || lowerMessage.includes('invalid')) {
                setEmailError(true);
            } else {
                setEmailError(true);
                setPasswordError(true);
            }
            return;
        }

        if (data) {
            setMessage("User account created!");
            setEmailError(false);
            setPasswordError(false);
        }

        setEmail("");
        setPassword("");
    }

    return (
        <div className="register-page">

            <div className="register-main">
                <img src={RecyclingHero} alt="Recycling hero" />
                <div className="form-container">
                    <h2>Register</h2>
                    <form onSubmit={handleSubmit}>


                        <label>Email</label>
                        <input
                            onChange={(e) => { setEmail(e.target.value); setEmailError(false); }}
                            value={email}
                            required
                            type="email" placeholder="yacine@gmail.com"
                            autoComplete="current-password"
                            className={emailError ? 'error' : ''} />
                        <label>Password</label>
                        <input
                            required
                            onChange={(e) => { setPassword(e.target.value); setPasswordError(false); }}
                            value={password}
                            type="password" placeholder="********"
                            autoComplete="current-password"
                            className={passwordError ? 'error' : ''} />
                            {message && <span className="error-message">{message}</span>}
                        <button type="submit">Create Account</button>
                        <div className="regisration-question">
                            <span className="register-span">Already have an account? </span>
                            <Link to="/login" id="register-link">Log in</Link>
                        </div>



                    </form>
                </div>


            </div>


        </div>
    );
}
