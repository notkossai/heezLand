import React from "react";
import "./LanguageSelect.css";

export default function LanguageSelector({ language, setLanguage }) {
  const handleChange = (e) => {
    setLanguage(e.target.value);
  };

  return (
    <div className="language-select">
      <select value={language} onChange={handleChange}>
        <option value="EN">EN</option>
        <option value="FR">FR</option>
        <option value="AR">AR</option>
      </select>
    </div>
  );
}
