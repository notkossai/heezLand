import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";

import cleanOceanBg from "/src/assets/videos/clean-ocean-bg.mp4";
import sealCharacter from "/src/assets/seal-character.png";
import oceanGarbage from "/src/assets/ocean-garbage.png";
import oceanStarter from "/src/assets/clean-ocean-starter.png"

import { OCEAN_ITEMS } from "../../data/oceanItemsData";
import "./CleanOcean.css";

const VIDEO_W = 1000;
const VIDEO_H = 562.5;

export default function CleanOcean() {
    const [drops, setDrops] = useState([]);
    const [score, setScore] = useState(0);
    const idRef = useRef(0);

    // Seal state
    const [sealX, setSealX] = useState(VIDEO_W * 0.4);
    const [sealDir, setSealDir] = useState(1); // 1 = right, -1 = left

    const [started, setStarted] = useState(false); // Add game start state
    const [gameOver, setGameOver] = useState(false);
    const [maxScore, setMaxScore] = useState(() => {
      const stored = localStorage.getItem('oceanMaxScore');
      return stored ? parseInt(stored, 10) : 0;
    });
    const [finalScore, setFinalScore] = useState(0);
    const [countdown, setCountdown] = useState(30);

    const containerRef = useRef(null);
    const videoRef = useRef(null);

    // precompute styles for each sprite slice
    const sprites = useMemo(() => OCEAN_ITEMS.map((s) => ({
        width: s.width,
        height: s.height,
        bgPos: `-${s.x}px 0px`,
    })), []);

    useEffect(() => {
        if (gameOver) return;
        const interval = setInterval(() => {
            idRef.current += 1;
            const sprite = sprites[Math.floor(Math.random() * sprites.length)];
            const maxX = VIDEO_W - sprite.width;
            const x = Math.max(0, Math.floor(Math.random() * (maxX + 1)));
            setDrops((prev) => [
                ...prev,
                {
                    id: idRef.current,
                    x,
                    sprite,
                    start: performance.now(),
                    duration: 2500,
                },
            ]);
        }, 1000);
        return () => clearInterval(interval);
    }, [sprites, gameOver]);

    // Collision detection and cleanup loop
    useEffect(() => {
        let raf;
        const tick = (now) => {
            setDrops((prev) => {
                const sealWidth = 120;
                const sealLeft = sealX;
                const sealRight = sealLeft + sealWidth;

                const next = [];
                let collected = 0;
                for (const d of prev) {
                    const t = Math.min(1, (now - d.start) / d.duration);
                    // Compute current top of item to match CSS movement
                    const yTop = -70 + t * 580;
                    const yBottom = yTop + d.sprite.height;

                    // Strict bottom boundary of video
                    const bottomBoundary = VIDEO_H;

                    // Horizontal extents
                    const itemLeft = d.x;
                    const itemRight = d.x + d.sprite.width;
                    const overlap = !(itemRight < sealLeft || itemLeft > sealRight);

                    // If item reached the bottom of the video
                    if (yBottom >= bottomBoundary) {
                        // If overlapping seal, count as collected; otherwise just remove
                        if (overlap) {
                            collected += 1;
                        }
                        continue; // drop the item either way
                    }

                    // Keep item if still falling above bottom
                    next.push(d);
                }
                if (collected && !gameOver) setScore((s) => s + collected);
                return next;
            });
            raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);
        return () => cancelAnimationFrame(raf);
    }, [sealX]);

    // Keyboard controls for the seal
    useEffect(() => {
        const STEP = 20; // pixels per key press
        const onKey = (e) => {
            if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
                e.preventDefault();
                setSealX((prev) => {
                    const next = e.key === 'ArrowLeft' ? prev - STEP : prev + STEP;
                    return Math.max(0, Math.min(VIDEO_W - 120, next)); // clamp, 120 ~ seal width
                });
                setSealDir(e.key === 'ArrowLeft' ? -1 : 1);
            }
        };
        window.addEventListener('keydown', onKey, { passive: false });
        return () => window.removeEventListener('keydown', onKey);
    }, []);

    // Ensure container is focusable and focused so onKeyDown also works
    useEffect(() => {
        if (containerRef.current) {
            containerRef.current.tabIndex = 0;
            containerRef.current.focus();
        }
    }, []);

    const handleContainerKeyDown = (e) => {
        const STEP = 20;
        if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
            e.preventDefault();
            setSealX((prev) => {
                const next = e.key === 'ArrowLeft' ? prev - STEP : prev + STEP;
                return Math.max(0, Math.min(VIDEO_W - 120, next));
            });
            setSealDir(e.key === 'ArrowLeft' ? -1 : 1);
        }
    };

    // Mouse move on video to position the seal
    const onMouseMove = (e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const localX = e.clientX - rect.left; // 0..VIDEO_W
        const clamped = Math.max(0, Math.min(VIDEO_W - 120, localX - 60)); // center the seal (assume ~120px width)
        setSealDir(localX < sealX ? -1 : 1);
        setSealX(clamped);
    };

    const resetGame = () => {
        setScore(0);
        setStarted(false);
        setGameOver(false);
        setCountdown(30);
    };
    useEffect(() => {
        if (!started) {
            setCountdown(30); // Reset countdown when game starts
            return;
        }
        if (countdown <= 0) {
            setGameOver(true); // Stop the game when countdown reaches 0
            setFinalScore(score);
            localStorage.setItem('final-score-ocean-cleaner', score.toString());
            if (score > maxScore) {
                setMaxScore(score);
                localStorage.setItem('oceanMaxScore', score.toString());
            }
            return;
        }
        const timer = setInterval(() => {
            setCountdown((prev) => prev - 1);
        }, 1000);

        return () => clearInterval(timer);
    }, [started, countdown, score, maxScore]);

    // Serve to target the body of this specific page (prevents Code and Mind Break down <3)

    useEffect(() => {
        document.body.classList.add("clean-ocean-body");

        return () => {
            document.body.classList.remove("clean-ocean-body");
        };
    }, []);

    return (
        <div className="clean-ocean-body">
            <div className="breadcrumb-trail-clean-ocean">
          <p><Link to="/Games" id="games-link">Games</Link> &gt; Ocean Cleaner</p>
        </div>
            
            <div
                ref={containerRef}
                className="clean-ocean-game-container"
                tabIndex={0}
                onKeyDown={handleContainerKeyDown}
            >
                
                {!started && !gameOver ? (
                    <div className="start-screen">
                        <h2>Clean the Ocean with Mr Seal!</h2>
                        <img src={oceanStarter} alt="Ocean Starter" />
                        <button className="start-cleaning-button" onClick={() => setStarted(true)}>Start Cleaning!</button>
                    </div>
                ) : gameOver ? (

                    <div className="game-over-screen-ocan-cleaner">
                        <div className="game-over-screen-ocan-cleaner-inside">
                            <p className="h3-replace-ocean-cleaner">Time's Up!</p>
                            <p className="final-score-ocean-cleaner" >Your final score is {finalScore}.</p>
                            <p>Max Score: {maxScore}</p>
                            <button onClick={resetGame}>Play Again</button>
                        </div>
                    </div>
                ) : (<>
                    <div className="video-wrapper" style={{ width: VIDEO_W, height: VIDEO_H }}>
                        <video
                            onMouseMove={onMouseMove}
                            width={VIDEO_W}
                            height={VIDEO_H}
                            autoPlay
                            loop
                            muted
                        >
                            <source src={cleanOceanBg} type="video/mp4" />
                            Your browser does not support the video tag.
                        </video>

                        {/* Overlay for falling items */}
                        <div className="ocean-items-overlay">
                            <div className="score-badge">Score: {score}</div>
                            <div className="countdown"><span>{countdown}</span>s</div>
                            {drops.map(({ id, x, sprite }) => (
                                <div
                                    key={id}
                                    className="ocean-drop"
                                    style={{ left: `${x}px`, width: `${sprite.width}px`, height: `${sprite.height}px` }}
                                >
                                    <div
                                        className="ocean-item"
                                        style={{
                                            width: `${sprite.width}px`,
                                            height: `${sprite.height}px`,
                                            backgroundImage: `url(${oceanGarbage})`,
                                            backgroundRepeat: "no-repeat",
                                            backgroundPosition: sprite.bgPos,
                                        }}
                                    />
                                </div>
                            ))}
                        </div>
                    </div>
                    <img
                        id="seal-character"
                        src={sealCharacter}
                        alt="Seal Image"
                        style={{
                            left: `${sealX}px`,
                            transform: `scaleX(${sealDir})`,
                            transformOrigin: 'center',
                            transition: 'left 80ms linear',
                        }}
                    />
                </>
                )}
                <div className={`game-area ${!started ? "blurred" : ""}`}>

                </div>
            </div>
        </div>
    );
}
