import PostDetail from "/src/Components/PostDetail";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";

import "./PostPage.css";

export default function PostPage() {
    const { id } = useParams();
    return (
        <div className="post-page-hall">
            <div className="menu">
                <Link to="/heros">
                    <button>Creations</button>
                </Link>

                <Link to="/create">
                    <button className="create">Create</button>
                </Link>
                <Link to="/dashboard">
                    <button>Profile</button>
                </Link>

            </div>
            <div className="post-page">
                <PostDetail postId={Number(id)} />
            </div>
        </div>

    );
}