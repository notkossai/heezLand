import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '/src/supabaseClient.js';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get session on first load
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // Listen for login/logout changes
    const { data: listener } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user ?? null);
    });

    return () => {
      listener.subscription.unsubscribe();
    };
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <AuthContext.Provider value={{ user, loading, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook (JS version)
export const useAuth = () => {
  const context = useContext(AuthContext);

  // Safety check
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider"); //This error is for me the developper will not show up for kids
  }

  return context;
};
