import { SupabaseClient } from "@supabase/supabase-js";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "/src/supabaseClient";
import { useAuth } from "/src/context/AuthContext";

import './LikeButton.css'

const fetchVotes = async (postId) => {
    const { data, error } = await supabase
        .from("votes")
        .select("*")
        .eq("post_id", postId);
    if (error) throw new Error(error.message);
    return data;
}
export default function LikeButton({ postId }) {
    const queryClient = useQueryClient();

    const vote = async (voteValue, postId, userId) => {

        const { data: existingVote } = await supabase
            .from("votes")
            .select("*")
            .eq("post_id", postId)
            .eq("user_id", userId)
            .maybeSingle()

        if (existingVote) {
            if (existingVote.vote === voteValue) {
                const { error } = await supabase
                    .from("votes")
                    .delete()
                    .eq("id", existingVote.id);

                if (error) throw new Error(error.message);
            } else {
                const { error } = await supabase
                    .from("votes")
                    .update({ vote: voteValue })
                    .eq("id", existingVote.id);

                if (error) throw new Error(error.message);
            }
        } else {
            const { error } = await supabase
                .from("votes")
                .insert({ post_id: postId, user_id: userId, vote: voteValue });
            if (error) throw new Error(error.message);
        }


    }

    const { user } = useAuth()

    const { mutate, isPending, error: mutationError } = useMutation({
        mutationFn: (voteValue) => {
            if (!user) throw new Error("You must be logged in to vote");
            return vote(voteValue, postId, user.id);
        },
        onSuccess: () => {
            // Invalidate and refetch immediately after successful vote
            queryClient.invalidateQueries({ queryKey: ["votes", postId] });
        }
    })

    const { data: votes, isLoading, error } = useQuery({
        queryKey: ["votes", postId],
        queryFn: () => fetchVotes(postId),
        refetchInterval: 5000, //refresh likes evry 5s without the user refreshing the page
    });

    if (isLoading) {
        return <div>Loading votes...</div>
    }

    if (error) {
        return <div>Error: {error.message}</div>
    }

    const likes = votes?.filter((v) => v.vote === 1).length || 0
    const dislikes = votes?.filter((v) => v.vote === -1).length || 0

    const userVote = user ? votes?.find(v => v.user_id === user.id)?.vote : null

    return (
        <div>
            {mutationError && <div style={{ color: "red" }}>Error voting: {mutationError.message}</div>}
            <button onClick={() => mutate(1)} className={userVote === 1 ? 'liked' : ''}>👍 {likes}</button>
            <button onClick={() => mutate(-1)} className={userVote === -1 ? 'disliked' : ''}>👎 {dislikes}</button>
        </div>
    );
}
